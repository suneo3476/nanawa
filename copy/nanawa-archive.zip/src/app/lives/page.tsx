import { redirect } from 'next/navigation';

export default function LivesPage() {
  // トップページにリダイレクト
  redirect('/');
}