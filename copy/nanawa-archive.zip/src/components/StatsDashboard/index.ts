export { StatsDashboard } from './StatsDashboard';
export { default } from './StatsDashboard';