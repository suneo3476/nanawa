import { SettingsProvider, useSettings } from './SettingsContext';

export { SettingsProvider, useSettings };
export default SettingsProvider;