import { Breadcrumbs } from './Breadcrumbs';

export { Breadcrumbs };
export default Breadcrumbs;