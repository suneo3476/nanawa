export type Song = {
  songId: string;
  title: string;
  album: string;
  releaseDate: string;
}
